/**
 * Electron 应用冒烟测试套件
 * 对应 07 章 - E2E 基线（Playwright × Electron）
 * 
 * 验证构建后的 Electron 应用符合安全基线和基本功能要求
 */

import { _electron as electron, ElectronApplication, Page } from 'playwright';
import { test, expect } from '@playwright/test';
import { ELECTRON_SECURITY_BASELINE } from '../../src/shared/contracts/build';

let app: ElectronApplication;
let page: Page;

test.beforeAll(async () => {
  // 启动构建后的 Electron 应用
  app = await electron.launch({ 
    args: ['./dist/electron/main.js'],
    env: { 
      NODE_ENV: 'test',
      CI: 'true' 
    }
  });
  
  // 等待主窗口加载
  page = await app.firstWindow();
  await page.waitForLoadState('domcontentloaded');
});

test.afterAll(async () => {
  if (app) {
    await app.close();
  }
});

test.describe('07章 Electron 基线验证', () => {
  
  test('应用启动并显示主窗口', async () => {
    // 窗口应该可见
    await expect(page).toBeVisible();
    
    // 应该有标题（使用占位符模式）
    const title = await page.title();
    expect(title).toBeTruthy();
    expect(title.length).toBeGreaterThan(0);
    
    // 应用应该完全加载
    await expect(page.locator('body')).toBeVisible();
  });

  test('安全基线：Node.js 全局变量隔离', async () => {
    // 验证危险的 Node.js 全局变量未暴露到渲染进程
    const nodeGlobals = await page.evaluate(() => {
      return {
        hasRequire: typeof (window as any).require !== 'undefined',
        hasProcess: typeof (window as any).process !== 'undefined', 
        hasBuffer: typeof (window as any).Buffer !== 'undefined',
        hasGlobal: typeof (window as any).global !== 'undefined',
        hasSetImmediate: typeof (window as any).setImmediate !== 'undefined',
        hasClearImmediate: typeof (window as any).clearImmediate !== 'undefined'
      };
    });
    
    expect(nodeGlobals.hasRequire, 'require() 不应暴露到渲染进程').toBe(false);
    expect(nodeGlobals.hasProcess, 'process 不应暴露到渲染进程').toBe(false);
    expect(nodeGlobals.hasBuffer, 'Buffer 不应暴露到渲染进程').toBe(false);
    expect(nodeGlobals.hasGlobal, 'global 不应暴露到渲染进程').toBe(false);
    expect(nodeGlobals.hasSetImmediate, 'setImmediate 不应暴露到渲染进程').toBe(false);
    expect(nodeGlobals.hasClearImmediate, 'clearImmediate 不应暴露到渲染进程').toBe(false);
  });

  test('安全基线：CSP 策略验证', async () => {
    // 检查 CSP meta 标签是否存在
    const cspMeta = await page.locator('meta[http-equiv="Content-Security-Policy"]');
    await expect(cspMeta).toBeAttached();
    
    // 获取 CSP 内容
    const cspContent = await cspMeta.getAttribute('content');
    expect(cspContent).toBeTruthy();
    
    // 验证基本的 CSP 指令
    expect(cspContent).toContain("default-src 'self'");
    expect(cspContent).toContain("script-src 'self'");
    
    console.log('✅ CSP 策略:', cspContent);
  });

  test('预加载脚本：白名单 API 验证', async () => {
    // 验证预加载脚本是否正确暴露了白名单 API
    const apiCheck = await page.evaluate(() => {
      // 使用占位符模式检查 API 暴露
      const windowKeys = Object.keys(window);
      const apiKeys = windowKeys.filter(key => key.includes('Api'));
      
      return {
        hasApiExposed: apiKeys.length > 0,
        exposedApiKeys: apiKeys,
        electronApi: typeof (window as any).electronAPI,
        customApi: typeof (window as any).__CUSTOM_API__ !== 'undefined'
      };
    });
    
    // 应该有某种形式的 API 暴露（具体名称取决于实际实现）
    console.log('🔍 暴露的 API 键:', apiCheck.exposedApiKeys);
    
    // 验证 API 通过 contextBridge 正确暴露
    expect(apiCheck.hasApiExposed || apiCheck.electronApi !== 'undefined' || apiCheck.customApi).toBeTruthy();
  });

  test('窗口属性：安全配置验证', async () => {
    // 通过主进程验证窗口的安全配置
    const windowConfig = await app.evaluate(async ({ BrowserWindow }) => {
      const windows = BrowserWindow.getAllWindows();
      if (windows.length === 0) return null;
      
      const mainWindow = windows[0];
      const webPreferences = mainWindow.webContents.getWebPreferences();
      
      return {
        nodeIntegration: webPreferences.nodeIntegration,
        contextIsolation: webPreferences.contextIsolation,
        sandbox: webPreferences.sandbox,
        webSecurity: webPreferences.webSecurity,
        allowRunningInsecureContent: webPreferences.allowRunningInsecureContent,
        experimentalFeatures: webPreferences.experimentalFeatures
      };
    });
    
    if (windowConfig) {
      expect(windowConfig.nodeIntegration, 'nodeIntegration 应为 false').toBe(false);
      expect(windowConfig.contextIsolation, 'contextIsolation 应为 true').toBe(true);
      expect(windowConfig.sandbox, 'sandbox 应为 true').toBe(true);
      expect(windowConfig.webSecurity, 'webSecurity 应为 true').toBe(true);
      expect(windowConfig.allowRunningInsecureContent, 'allowRunningInsecureContent 应为 false').toBe(false);
      expect(windowConfig.experimentalFeatures, 'experimentalFeatures 应为 false').toBe(false);
      
      console.log('✅ 窗口安全配置验证通过');
    }
  });

  test('基本交互：应用响应性测试', async () => {
    // 测试基本的 UI 交互响应
    const startTime = Date.now();
    
    // 尝试点击应用中的某个元素（如果存在）
    const clickableElements = await page.locator('button, [role="button"], [data-testid]').count();
    
    if (clickableElements > 0) {
      const firstButton = page.locator('button, [role="button"], [data-testid]').first();
      await firstButton.click({ timeout: 5000 });
      
      const responseTime = Date.now() - startTime;
      expect(responseTime, '交互响应时间应小于 200ms').toBeLessThan(200);
      
      console.log(`✅ 交互响应时间: ${responseTime}ms`);
    } else {
      console.log('⚠️  未找到可交互元素，跳过交互测试');
    }
  });

  test('内存使用：基线检查', async () => {
    // 检查渲染进程的内存使用情况
    const memoryInfo = await page.evaluate(() => {
      if ('memory' in performance) {
        const memory = (performance as any).memory;
        return {
          usedJSHeapSize: memory.usedJSHeapSize,
          totalJSHeapSize: memory.totalJSHeapSize,
          jsHeapSizeLimit: memory.jsHeapSizeLimit
        };
      }
      return null;
    });
    
    if (memoryInfo) {
      // 基本的内存健康检查
      expect(memoryInfo.usedJSHeapSize).toBeGreaterThan(0);
      expect(memoryInfo.usedJSHeapSize).toBeLessThan(memoryInfo.totalJSHeapSize);
      
      const memoryUsageMB = memoryInfo.usedJSHeapSize / 1024 / 1024;
      console.log(`📊 JS 堆内存使用: ${memoryUsageMB.toFixed(2)} MB`);
      
      // 警告：如果初始内存使用过高
      if (memoryUsageMB > 100) {
        console.warn(`⚠️  初始内存使用较高: ${memoryUsageMB.toFixed(2)} MB`);
      }
    }
  });

  test('错误处理：未捕获异常检测', async () => {
    let consoleErrors: string[] = [];
    let unhandledErrors: string[] = [];
    
    // 监听控制台错误
    page.on('console', msg => {
      if (msg.type() === 'error') {
        consoleErrors.push(msg.text());
      }
    });
    
    // 监听未处理的异常
    page.on('pageerror', err => {
      unhandledErrors.push(err.message);
    });
    
    // 等待一段时间收集错误
    await page.waitForTimeout(2000);
    
    // 过滤掉已知的无害错误（如开发工具相关）
    const significantErrors = consoleErrors.filter(error => 
      !error.includes('DevTools') && 
      !error.includes('Extension') &&
      !error.includes('chrome-extension')
    );
    
    if (significantErrors.length > 0) {
      console.warn('⚠️  发现控制台错误:', significantErrors);
    }
    
    if (unhandledErrors.length > 0) {
      console.error('❌ 发现未处理异常:', unhandledErrors);
    }
    
    // 在冒烟测试中，不应有严重的未处理异常
    expect(unhandledErrors.length, '不应有未处理异常').toBe(0);
  });

  test('应用关闭：清理验证', async () => {
    // 验证应用能够正常关闭
    const isOpen = await app.evaluate(async ({ app }) => {
      return !app.isReady() || app.isReady();
    });
    
    expect(isOpen).toBeTruthy();
    
    // 应用应该能响应关闭信号
    // 这个测试将在 afterAll 中实际执行关闭
    console.log('✅ 应用状态检查通过');
  });
});

test.describe('07章 构建产物验证', () => {
  
  test('构建产物：文件完整性检查', async () => {
    // 验证关键的构建产物是否存在
    const buildInfo = await app.evaluate(async () => {
      const path = require('path');
      const fs = require('fs');
      
      const expectedFiles = [
        'package.json',
        'dist/electron/main.js',
        'dist/electron/preload.js'
      ];
      
      const existingFiles = expectedFiles.filter(file => {
        try {
          return fs.existsSync(file);
        } catch {
          return false;
        }
      });
      
      return {
        expectedCount: expectedFiles.length,
        existingCount: existingFiles.length,
        existingFiles
      };
    });
    
    console.log('📁 构建产物检查:', buildInfo);
    
    // 至少应该有主要的构建产物
    expect(buildInfo.existingCount).toBeGreaterThan(0);
  });

  test('版本信息：应用元数据验证', async () => {
    // 获取应用版本信息
    const appVersion = await app.evaluate(async ({ app }) => {
      return {
        version: app.getVersion(),
        name: app.getName(),
        ready: app.isReady()
      };
    });
    
    expect(appVersion.version).toBeTruthy();
    expect(appVersion.name).toBeTruthy();
    expect(appVersion.ready).toBe(true);
    
    console.log('📦 应用信息:', appVersion);
  });
});

// TODO: 添加性能基线测试（帧率、响应时间）
// TODO: 添加与主进程的 IPC 通信测试
// TODO: 添加自动更新机制测试（如果适用）
// TODO: 添加多窗口场景测试
// TODO: 集成 Release Health 指标收集