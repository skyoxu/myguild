/**
 * 公会管理器安全基线测试
 * 验证 Electron 安全配置和 CSP 合规性
 */

import { test, expect, Page, ElectronApplication, _electron } from '@playwright/test';

let testApp: { electronApp: ElectronApplication; page: Page };

test.beforeAll(async () => {
  const electronApp = await _electron.launch({
    args: ['dist-electron/main.js'],
    env: {
      NODE_ENV: 'test',
      SECURITY_TEST_MODE: 'true'
    }
  });

  const page = await electronApp.firstWindow();
  await page.waitForLoadState('domcontentloaded');

  testApp = { electronApp, page };
});

test.afterAll(async () => {
  if (testApp?.electronApp) {
    await testApp.electronApp.close();
  }
});

test.describe('Guild Manager - Electron Security Baseline', () => {
  test('should enforce nodeIntegration=false', async () => {
    const { page } = testApp;
    
    // 验证 Node.js API 不可访问
    const nodeAccessible = await page.evaluate(() => {
      // 尝试访问 Node.js 全局对象
      try {
        return typeof process !== 'undefined' && 
               typeof require !== 'undefined' &&
               typeof global !== 'undefined';
      } catch {
        return false;
      }
    });
    
    expect(nodeAccessible).toBe(false);
    
    // 验证常见 Node.js 模块不可访问
    const moduleTests = await page.evaluate(() => {
      const results: { [key: string]: boolean } = {};
      
      const testModules = ['fs', 'path', 'os', 'crypto', 'child_process'];
      
      testModules.forEach(moduleName => {
        try {
          results[moduleName] = typeof require(moduleName) !== 'undefined';
        } catch {
          results[moduleName] = false;
        }
      });
      
      return results;
    });
    
    Object.values(moduleTests).forEach(accessible => {
      expect(accessible).toBe(false);
    });
  });

  test('should enforce contextIsolation=true', async () => {
    const { page } = testApp;
    
    // 验证 contextBridge API 可用但直接访问不可用
    const contextIsolation = await page.evaluate(() => {
      return {
        // 检查是否有 electronAPI（通过 contextBridge 暴露）
        hasElectronAPI: typeof window.electronAPI !== 'undefined',
        
        // 检查是否无法直接访问 Electron API
        hasDirectElectron: typeof window.electron !== 'undefined' ||
                          typeof window.ipcRenderer !== 'undefined' ||
                          typeof window.webFrame !== 'undefined',
        
        // 检查是否无法访问原生 Electron 对象
        hasNativeAccess: typeof window.require !== 'undefined' ||
                        typeof window.process !== 'undefined' ||
                        typeof window.global !== 'undefined'
      };
    });
    
    // 应该有通过 contextBridge 暴露的 API
    expect(contextIsolation.hasElectronAPI).toBe(true);
    
    // 不应该有直接的 Electron API 访问
    expect(contextIsolation.hasDirectElectron).toBe(false);
    
    // 不应该有原生访问能力
    expect(contextIsolation.hasNativeAccess).toBe(false);
  });

  test('should enforce sandbox=true', async () => {
    const { page } = testApp;
    
    // 验证沙盒环境限制
    const sandboxTests = await page.evaluate(() => {
      const results: { [key: string]: any } = {};
      
      // 测试 eval 是否被限制
      try {
        results.evalBlocked = eval('1+1') === 2;
      } catch (error) {
        results.evalBlocked = false;
        results.evalError = (error as Error).message;
      }
      
      // 测试 Function 构造函数是否被限制
      try {
        results.functionConstructorBlocked = new Function('return 1+1')() === 2;
      } catch (error) {
        results.functionConstructorBlocked = false;
        results.functionConstructorError = (error as Error).message;
      }
      
      // 测试是否无法访问系统信息
      results.hasNavigatorHardwareConcurrency = typeof navigator.hardwareConcurrency !== 'undefined';
      results.hasNavigatorPlatform = typeof navigator.platform !== 'undefined';
      
      // 检查是否在沙盒中（某些 API 会被限制）
      results.isInSandbox = typeof window.origin !== 'undefined' && 
                           window.origin === 'file://';
      
      return results;
    });
    
    // 在严格沙盒模式下，某些功能应该被限制
    console.log('Sandbox test results:', sandboxTests);
    
    // 验证基本安全限制生效
    expect(typeof sandboxTests.evalBlocked).toBe('boolean');
    expect(typeof sandboxTests.functionConstructorBlocked).toBe('boolean');
  });

  test('should enforce strict Content Security Policy', async () => {
    const { page } = testApp;
    
    // 获取 CSP 头信息
    const cspInfo = await page.evaluate(() => {
      const metaTags = Array.from(document.querySelectorAll('meta[http-equiv="Content-Security-Policy"]'));
      return metaTags.map(tag => tag.getAttribute('content')).join('; ');
    });
    
    expect(cspInfo).toBeTruthy();
    console.log('CSP Policy:', cspInfo);
    
    // 验证关键 CSP 指令
    expect(cspInfo).toContain("default-src 'self'");
    expect(cspInfo).toContain("script-src 'self'");
    expect(cspInfo).toContain("style-src 'self'");
    
    // 验证不允许 unsafe-eval 和 unsafe-inline
    expect(cspInfo).not.toContain("'unsafe-eval'");
    expect(cspInfo).not.toContain("'unsafe-inline'");
    
    // 测试 CSP 违规检测
    const cspViolation = await page.evaluate(() => {
      return new Promise((resolve) => {
        let violationDetected = false;
        
        // 监听 CSP 违规事件
        document.addEventListener('securitypolicyviolation', (e) => {
          violationDetected = true;
          resolve({
            violation: true,
            directive: e.violatedDirective,
            blockedURI: e.blockedURI,
            disposition: e.disposition
          });
        });
        
        // 尝试执行违反 CSP 的操作
        try {
          const script = document.createElement('script');
          script.textContent = 'console.log("CSP test");';
          document.head.appendChild(script);
        } catch (error) {
          // 如果被阻止，这是期望的行为
        }
        
        // 等待一段时间检查是否有违规事件
        setTimeout(() => {
          if (!violationDetected) {
            resolve({ violation: false });
          }
        }, 1000);
      });
    });
    
    // CSP 应该阻止内联脚本执行
    expect((cspViolation as any).violation).toBe(true);
  });

  test('should validate secure IPC communication', async () => {
    const { page } = testApp;
    
    // 测试 IPC 通信安全性
    const ipcTests = await page.evaluate(() => {
      if (!window.electronAPI) {
        return { error: 'electronAPI not available' };
      }
      
      const results: { [key: string]: any } = {};
      
      // 验证只能访问白名单 API
      const allowedMethods = [
        'onCloudEvent',
        'sendCloudEvent',
        'getGuildData',
        'updateGuildResources'
      ];
      
      allowedMethods.forEach(method => {
        results[method] = typeof window.electronAPI![method] === 'function';
      });
      
      // 验证不能访问危险的系统 API
      const dangerousMethods = [
        'executeCommand',
        'readFile',
        'writeFile',
        'openDialog',
        'shell'
      ];
      
      dangerousMethods.forEach(method => {
        results[`blocked_${method}`] = typeof window.electronAPI![method] === 'undefined';
      });
      
      return results;
    });
    
    if ((ipcTests as any).error) {
      test.skip('electronAPI not available for testing');
      return;
    }
    
    console.log('IPC Security Tests:', ipcTests);
    
    // 验证白名单方法可用
    expect((ipcTests as any).onCloudEvent).toBe(true);
    expect((ipcTests as any).sendCloudEvent).toBe(true);
    
    // 验证危险方法被阻止
    expect((ipcTests as any).blocked_executeCommand).toBe(true);
    expect((ipcTests as any).blocked_readFile).toBe(true);
    expect((ipcTests as any).blocked_writeFile).toBe(true);
  });

  test('should prevent XSS attacks', async () => {
    const { page } = testApp;
    
    // 测试 XSS 防护
    const xssTests = await page.evaluate(() => {
      const results: { [key: string]: any } = {};
      
      // 测试 innerHTML XSS 防护
      const testDiv = document.createElement('div');
      testDiv.innerHTML = '<script>window.xssTest = true;</script><img src="x" onerror="window.xssTest2 = true">';
      document.body.appendChild(testDiv);
      
      // 等待执行
      setTimeout(() => {
        results.xssTest = typeof window.xssTest !== 'undefined';
        results.xssTest2 = typeof window.xssTest2 !== 'undefined';
        document.body.removeChild(testDiv);
      }, 100);
      
      // 测试 URL 参数 XSS
      const urlParams = new URLSearchParams('?test=<script>alert(1)</script>');
      results.urlParamXSS = urlParams.get('test');
      
      return results;
    });
    
    // 等待测试完成
    await page.waitForTimeout(200);
    
    const finalResults = await page.evaluate(() => ({
      xssTest: typeof window.xssTest !== 'undefined',
      xssTest2: typeof window.xssTest2 !== 'undefined'
    }));
    
    // XSS 攻击应该被阻止
    expect(finalResults.xssTest).toBe(false);
    expect(finalResults.xssTest2).toBe(false);
  });

  test('should validate secure data handling', async () => {
    const { page } = testApp;
    
    // 测试敏感数据处理安全性
    await page.evaluate(() => {
      // 模拟处理敏感数据
      const sensitiveData = {
        apiKey: 'secret-api-key-123',
        userToken: 'jwt-token-456',
        encryptionKey: 'encryption-key-789'
      };
      
      // 确保敏感数据不会泄露到全局作用域
      if (window.testSensitiveData) {
        delete window.testSensitiveData;
      }
      
      // 存储在安全的本地变量中
      let localSensitiveData = { ...sensitiveData };
      
      // 清理操作
      localSensitiveData = {} as any;
      
      return true;
    });
    
    // 验证敏感数据没有泄露到全局
    const leakedData = await page.evaluate(() => {
      const globalKeys = Object.keys(window);
      return globalKeys.filter(key => 
        key.toLowerCase().includes('secret') ||
        key.toLowerCase().includes('token') ||
        key.toLowerCase().includes('key')
      );
    });
    
    expect(leakedData.length).toBe(0);
  });

  test('should validate secure storage mechanisms', async () => {
    const { page } = testApp;
    
    // 测试存储安全性
    const storageTests = await page.evaluate(() => {
      const results: { [key: string]: any } = {};
      
      // 测试 localStorage 是否可用但受限
      try {
        localStorage.setItem('test', 'value');
        results.localStorageAvailable = localStorage.getItem('test') === 'value';
        localStorage.removeItem('test');
      } catch (error) {
        results.localStorageError = (error as Error).message;
      }
      
      // 测试 sessionStorage 是否可用但受限
      try {
        sessionStorage.setItem('test', 'value');
        results.sessionStorageAvailable = sessionStorage.getItem('test') === 'value';
        sessionStorage.removeItem('test');
      } catch (error) {
        results.sessionStorageError = (error as Error).message;
      }
      
      // 测试 IndexedDB 是否可用
      results.indexedDBAvailable = typeof indexedDB !== 'undefined';
      
      // 测试 Cookie 设置限制
      try {
        document.cookie = 'test=value; secure; samesite=strict';
        results.cookieSet = document.cookie.includes('test=value');
      } catch (error) {
        results.cookieError = (error as Error).message;
      }
      
      return results;
    });
    
    console.log('Storage Security Tests:', storageTests);
    
    // 验证存储机制可用但安全
    if (storageTests.localStorageAvailable) {
      expect(storageTests.localStorageAvailable).toBe(true);
    }
    
    if (storageTests.sessionStorageAvailable) {
      expect(storageTests.sessionStorageAvailable).toBe(true);
    }
    
    // IndexedDB 应该可用于本地数据存储
    expect(storageTests.indexedDBAvailable).toBe(true);
  });
});

test.describe('Guild Manager - Security Compliance', () => {
  test('should comply with OWASP security guidelines', async () => {
    const { page } = testApp;
    
    // OWASP Top 10 基本检查
    const owaspChecks = await page.evaluate(() => {
      const results: { [key: string]: any } = {};
      
      // A01: Broken Access Control - 检查权限控制
      results.accessControlEnabled = typeof window.electronAPI !== 'undefined' &&
                                    typeof window.electronAPI.checkPermissions === 'function';
      
      // A02: Cryptographic Failures - 检查加密能力
      results.cryptoAPIAvailable = typeof crypto !== 'undefined' &&
                                  typeof crypto.getRandomValues === 'function';
      
      // A03: Injection - 检查输入验证
      results.inputValidationActive = typeof window.electronAPI !== 'undefined' &&
                                     typeof window.electronAPI.validateInput === 'function';
      
      // A05: Security Misconfiguration - 检查安全配置
      const cspMeta = document.querySelector('meta[http-equiv="Content-Security-Policy"]');
      results.cspConfigured = cspMeta !== null;
      
      // A06: Vulnerable Components - 检查组件安全
      results.secureComponentsUsed = typeof window.electronAPI !== 'undefined';
      
      return results;
    });
    
    console.log('OWASP Compliance Checks:', owaspChecks);
    
    // 基本安全配置应该到位
    expect(owaspChecks.cspConfigured).toBe(true);
    expect(owaspChecks.cryptoAPIAvailable).toBe(true);
    expect(owaspChecks.secureComponentsUsed).toBe(true);
  });

  test('should handle security headers correctly', async () => {
    const { page } = testApp;
    
    // 检查安全相关的响应头
    const securityHeaders = await page.evaluate(() => {
      const headers: { [key: string]: string } = {};
      
      // 检查 CSP 头
      const cspMeta = document.querySelector('meta[http-equiv="Content-Security-Policy"]');
      if (cspMeta) {
        headers['content-security-policy'] = cspMeta.getAttribute('content') || '';
      }
      
      // 检查其他安全头
      const metaTags = document.querySelectorAll('meta[http-equiv]');
      metaTags.forEach(tag => {
        const httpEquiv = tag.getAttribute('http-equiv')?.toLowerCase();
        const content = tag.getAttribute('content');
        if (httpEquiv && content) {
          headers[httpEquiv] = content;
        }
      });
      
      return headers;
    });
    
    console.log('Security Headers:', securityHeaders);
    
    // 验证关键安全头存在
    expect(securityHeaders['content-security-policy']).toBeTruthy();
    
    // 如果设置了其他安全头，验证其配置
    if (securityHeaders['x-frame-options']) {
      expect(['DENY', 'SAMEORIGIN'].includes(securityHeaders['x-frame-options'])).toBe(true);
    }
    
    if (securityHeaders['x-content-type-options']) {
      expect(securityHeaders['x-content-type-options']).toBe('nosniff');
    }
  });

  test('should prevent information disclosure', async () => {
    const { page } = testApp;
    
    // 检查是否泄露敏感信息
    const informationLeakage = await page.evaluate(() => {
      const results: { [key: string]: any } = {};
      
      // 检查错误信息是否包含敏感路径
      try {
        throw new Error('Test error');
      } catch (error) {
        const errorMessage = (error as Error).message;
        results.errorContainsPath = errorMessage.includes('/') || errorMessage.includes('\\');
        results.errorMessage = errorMessage;
      }
      
      // 检查是否暴露开发者工具信息
      results.devToolsDetection = typeof window.devtools !== 'undefined';
      
      // 检查是否暴露构建信息
      results.buildInfoExposed = typeof window.BUILD_INFO !== 'undefined' ||
                                typeof window.VERSION !== 'undefined';
      
      // 检查控制台是否清理
      const consoleLogCount = console.log.toString().includes('[native code]');
      results.consoleClean = consoleLogCount;
      
      return results;
    });
    
    console.log('Information Disclosure Checks:', informationLeakage);
    
    // 验证不泄露敏感信息
    expect(informationLeakage.devToolsDetection).toBe(false);
    
    // 在生产环境中不应暴露构建信息
    if (process.env.NODE_ENV === 'production') {
      expect(informationLeakage.buildInfoExposed).toBe(false);
    }
  });
});

// 扩展全局类型
declare global {
  interface Window {
    electronAPI?: {
      checkPermissions?: () => Promise<boolean>;
      validateInput?: (input: string) => boolean;
      [key: string]: any;
    };
    devtools?: any;
    BUILD_INFO?: any;
    VERSION?: any;
    testSensitiveData?: any;
    xssTest?: boolean;
    xssTest2?: boolean;
  }
}