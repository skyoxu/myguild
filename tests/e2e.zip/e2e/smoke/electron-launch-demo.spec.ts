import { test, expect, _electron as electron } from '@playwright/test';
import path from 'path';

/**
 * Electron冒烟测试示例 - _electron.launch()官方模式
 * 基于ADR-0002 Electron安全基线验证
 * 
 * 测试内容：
 * - 应用基本启动和窗口管理
 * - 上下文隔离和Node.js访问限制
 * - CSP策略生效验证
 * - IPC通道安全测试
 * - 主进程和渲染进程分离验证
 */

test.describe('Electron应用基础功能', () => {
  test('应用启动和窗口创建', async () => {
    // 使用_electron.launch()官方模式启动应用
    const electronApp = await electron.launch({
      args: [path.join(__dirname, '../../../dist-electron/main.js')],
      timeout: 30000
    });

    // 等待主窗口创建
    const firstWindow = await electronApp.firstWindow({
      timeout: 15000
    });

    // 验证窗口基本属性
    await expect(firstWindow).toHaveTitle(/Guild Manager|公会管理器/);
    
    // 验证窗口尺寸（基于设计要求）
    const viewportSize = firstWindow.viewportSize();
    expect(viewportSize?.width).toBeGreaterThan(800);
    expect(viewportSize?.height).toBeGreaterThan(600);

    // 清理：关闭应用
    await electronApp.close();
  });

  test('安全基线验证 - 上下文隔离', async () => {
    const electronApp = await electron.launch({
      args: [path.join(__dirname, '../../../dist-electron/main.js')]
    });

    const firstWindow = await electronApp.firstWindow();

    // 验证上下文隔离 - Node.js API不可访问
    const nodeAccessBlocked = await firstWindow.evaluate(() => {
      return typeof require === 'undefined' && 
             typeof process === 'undefined' && 
             typeof Buffer === 'undefined';
    });

    expect(nodeAccessBlocked).toBe(true);

    // 验证contextBridge API可用（如果配置了）
    const bridgeAvailable = await firstWindow.evaluate(() => {
      return typeof window.electronAPI !== 'undefined' || 
             typeof window.electron !== 'undefined';
    });

    // contextBridge应该暴露白名单API
    if (bridgeAvailable) {
      console.log('✅ contextBridge API已正确暴露');
    } else {
      console.log('ℹ️ 未检测到contextBridge API，请确认是否需要IPC通信');
    }

    await electronApp.close();
  });

  test('CSP策略生效验证', async () => {
    const electronApp = await electron.launch({
      args: [path.join(__dirname, '../../../dist-electron/main.js')]
    });

    const firstWindow = await electronApp.firstWindow();

    // 验证内联脚本被阻止
    const inlineScriptBlocked = await firstWindow.evaluate(async () => {
      return new Promise((resolve) => {
        const script = document.createElement('script');
        script.innerHTML = 'window.testCSP = true;';
        script.onerror = () => resolve(true); // CSP阻止了内联脚本
        script.onload = () => resolve(false); // CSP未生效
        
        // 添加超时保险
        setTimeout(() => resolve(false), 2000);
        
        document.head.appendChild(script);
      });
    });

    expect(inlineScriptBlocked).toBe(true);

    await electronApp.close();
  });

  test('主进程和渲染进程分离', async () => {
    const electronApp = await electron.launch({
      args: [path.join(__dirname, '../../../dist-electron/main.js')]
    });

    // 验证主进程存在
    expect(electronApp).toBeTruthy();

    const firstWindow = await electronApp.firstWindow();

    // 验证渲染进程独立运行
    const rendererInfo = await firstWindow.evaluate(() => ({
      userAgent: navigator.userAgent,
      isElectron: navigator.userAgent.includes('Electron'),
      hasNodeIntegration: typeof require !== 'undefined'
    }));

    expect(rendererInfo.isElectron).toBe(true);
    expect(rendererInfo.hasNodeIntegration).toBe(false); // 应该被隔离

    await electronApp.close();
  });
});

test.describe('性能和响应性验证', () => {
  test('应用启动时间测试', async () => {
    const startTime = Date.now();
    
    const electronApp = await electron.launch({
      args: [path.join(__dirname, '../../../dist-electron/main.js')]
    });

    const firstWindow = await electronApp.firstWindow();
    
    // 等待应用完全加载
    await firstWindow.waitForLoadState('domcontentloaded');
    
    const launchTime = Date.now() - startTime;
    
    // 启动时间应在合理范围内（基于ADR-0005性能要求）
    expect(launchTime).toBeLessThan(10000); // 10秒内启动
    
    console.log(`应用启动时间: ${launchTime}ms`);

    await electronApp.close();
  });

  test('窗口响应性测试', async () => {
    const electronApp = await electron.launch({
      args: [path.join(__dirname, '../../../dist-electron/main.js')]
    });

    const firstWindow = await electronApp.firstWindow();
    await firstWindow.waitForLoadState('domcontentloaded');

    // 测试基本UI交互响应时间
    const startTime = Date.now();
    
    // 点击测试（如果有可点击元素）
    try {
      await firstWindow.click('body', { timeout: 1000 });
      const responseTime = Date.now() - startTime;
      
      // P95响应时间应≤100ms（基于ADR-0005）
      expect(responseTime).toBeLessThan(200); // 允许一定容差
      
      console.log(`UI响应时间: ${responseTime}ms`);
    } catch {
      // 如果没有可交互元素，跳过此项测试
      console.log('ℹ️ 跳过UI交互测试（无可交互元素）');
    }

    await electronApp.close();
  });
});

test.describe('错误处理和稳定性', () => {
  test('应用意外退出恢复', async () => {
    const electronApp = await electron.launch({
      args: [path.join(__dirname, '../../../dist-electron/main.js')]
    });

    const firstWindow = await electronApp.firstWindow();

    // 验证应用稳定运行
    await firstWindow.waitForLoadState('domcontentloaded');
    
    // 模拟页面刷新（测试应用稳定性）
    await firstWindow.reload();
    await firstWindow.waitForLoadState('domcontentloaded');

    // 验证应用仍然正常
    const isVisible = await firstWindow.isVisible('body');
    expect(isVisible).toBe(true);

    await electronApp.close();
  });

  test('内存泄漏基础检查', async () => {
    const electronApp = await electron.launch({
      args: [path.join(__dirname, '../../../dist-electron/main.js')]
    });

    const firstWindow = await electronApp.firstWindow();
    await firstWindow.waitForLoadState('domcontentloaded');

    // 基础内存使用情况检查
    const memoryInfo = await firstWindow.evaluate(() => {
      // @ts-ignore - performance.memory可能不在所有环境可用
      return (performance as any).memory ? {
        used: (performance as any).memory.usedJSHeapSize,
        total: (performance as any).memory.totalJSHeapSize,
        limit: (performance as any).memory.jsHeapSizeLimit
      } : null;
    });

    if (memoryInfo) {
      console.log('内存使用情况:', memoryInfo);
      
      // 验证内存使用合理
      const memoryUsageRatio = memoryInfo.used / memoryInfo.limit;
      expect(memoryUsageRatio).toBeLessThan(0.8); // 内存使用不超过80%
    }

    await electronApp.close();
  });
});