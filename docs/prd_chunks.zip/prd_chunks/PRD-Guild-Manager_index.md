# PRD-Guild-Manager Document Chunks Index

Total chunks: 24
Original file: PRD-Guild-Manager.md
Chunk size: ~8000 chars

## Chunks List

- [PRD-Guild-Manager_chunk_001.md](./PRD-Guild-Manager_chunk_001.md)
- [PRD-Guild-Manager_chunk_002.md](./PRD-Guild-Manager_chunk_002.md)
- [PRD-Guild-Manager_chunk_003.md](./PRD-Guild-Manager_chunk_003.md)
- [PRD-Guild-Manager_chunk_004.md](./PRD-Guild-Manager_chunk_004.md)
- [PRD-Guild-Manager_chunk_005.md](./PRD-Guild-Manager_chunk_005.md)
- [PRD-Guild-Manager_chunk_006.md](./PRD-Guild-Manager_chunk_006.md)
- [PRD-Guild-Manager_chunk_007.md](./PRD-Guild-Manager_chunk_007.md)
- [PRD-Guild-Manager_chunk_008.md](./PRD-Guild-Manager_chunk_008.md)
- [PRD-Guild-Manager_chunk_009.md](./PRD-Guild-Manager_chunk_009.md)
- [PRD-Guild-Manager_chunk_010.md](./PRD-Guild-Manager_chunk_010.md)
- [PRD-Guild-Manager_chunk_011.md](./PRD-Guild-Manager_chunk_011.md)
- [PRD-Guild-Manager_chunk_012.md](./PRD-Guild-Manager_chunk_012.md)
- [PRD-Guild-Manager_chunk_013.md](./PRD-Guild-Manager_chunk_013.md)
- [PRD-Guild-Manager_chunk_014.md](./PRD-Guild-Manager_chunk_014.md)
- [PRD-Guild-Manager_chunk_015.md](./PRD-Guild-Manager_chunk_015.md)
- [PRD-Guild-Manager_chunk_016.md](./PRD-Guild-Manager_chunk_016.md)
- [PRD-Guild-Manager_chunk_017.md](./PRD-Guild-Manager_chunk_017.md)
- [PRD-Guild-Manager_chunk_018.md](./PRD-Guild-Manager_chunk_018.md)
- [PRD-Guild-Manager_chunk_019.md](./PRD-Guild-Manager_chunk_019.md)
- [PRD-Guild-Manager_chunk_020.md](./PRD-Guild-Manager_chunk_020.md)
- [PRD-Guild-Manager_chunk_021.md](./PRD-Guild-Manager_chunk_021.md)
- [PRD-Guild-Manager_chunk_022.md](./PRD-Guild-Manager_chunk_022.md)
- [PRD-Guild-Manager_chunk_023.md](./PRD-Guild-Manager_chunk_023.md)
- [PRD-Guild-Manager_chunk_024.md](./PRD-Guild-Manager_chunk_024.md)
